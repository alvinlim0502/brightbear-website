
# Bright Bear Preschool Website

This is the static website for Bright Bear Preschool.

## Deploy to GitHub Pages
1. Create a new public repository on GitHub.
2. Upload all files in this folder to the repository root.
3. Go to Settings > Pages, set Branch to main and folder to / (root).
4. Save and wait for the site to be live.
